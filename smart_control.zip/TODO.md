# TODO List

## Overview
Keep track of your tasks and stay organized. Use the checkboxes to mark completion.

---

## Tasks

### Not Started
- [ ] Add a filter for clients search "IF SOLD"
- [ ] Add a search in service

### Pending
- [ ] Show Client Infos in the popup

### In Progress
- [ ] API development

### Done
- [X] New service section (new button in the navbar, and new features)